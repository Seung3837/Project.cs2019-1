﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Team
{
    class People
    {
        private string name {get; set;}
        private string id { get; set; }
        private string phoneNumber { get; set; }
        private string birth { get; set; }

        private List<Lecture> lecture;

        public People()
        {
            name = "";
            id = "";
            phoneNumber = "";
            birth = "";
        }

        ~People()
        {

        }



    }
}
