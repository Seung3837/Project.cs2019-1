﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Team
{
    class Lecture
    {
        private string classroom { get; set; }
        private string startTime { get; set; }
        private string finishTime { get; set; }
        private string teacher { get; set; }
        private string classname { get; set; }
        private string id { get; set; }
        private List<Student> student;

        public Lecture()
        {
            classroom = "";
            startTime = "";
            finishTime = "";
            teacher = "";
            classname = "";
            id = "";
        }

        ~Lecture()
        {

        }
    }
}
