﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Team
{
    class Teacher : People
    {
        private string position { get; set; }

        public Teacher() : base()
        {
            position = "";
        }

        ~Teacher()
        {

        }


    }
}
