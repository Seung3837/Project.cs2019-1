﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Team
{
    class Student : People
    {
        private string grade { get; set; }
        private string school { get; set; }
        private int usingTime { get; set; }

        public Student() : base()
        {
            grade = "";
            school = "";
            usingTime = 0;
        }

        ~Student()
        {

        }
    }
}
