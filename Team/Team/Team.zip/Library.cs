﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Team
{
    class Library
    {
        private Desk[] desk;

        public Library()
        {
            desk = new Desk[20];
            for (int i = 0; i < 20; i++)
                desk[i] = new Desk();
        }
        private class Desk
        {
            private Student student;
            private string startTime;
            private string finishTime { get; set; }
            private bool valid;

            public Desk()
            {
                valid = true;
            }
            ~Desk()
            {

            }

            public void startDesk(Student student)
            {
                this.student = student;
                startTime = DateTime.Now.ToString("hh:mm:ss");
                valid = false;
            }

            public void finishDest()
            {
                valid = false;
                finishTime = DateTime.Now.ToString("hh:mm:ss");

                // 여기다가 finishTime - startTime int형 변환해서 this.student usingTime에 넣으면 됨
            }
        }

    }
}
